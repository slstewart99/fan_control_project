import setuptools

setuptools.setup(
    name="multi-fan-control",
    version="0.0.1",
    author="Stan Stewart",
    author_email="sbstewart@earthlink.net",
    description="Controls up to 10 fans cooling 5 subsystems",
    license='Python Packaging Authority',
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        'License :: OSI Approved :: Python Software Foundation License'
        "Operating System :: OS Independent",
    ],
    package_data={
        # If any package contains *.txt or *.rst files, include them:
        '': ['*.txt', '*.rst'],
    },
    python_requires='>=3.7',
    #url="https://github.com/junk/junk/junk",
)
