#!/usr/bin/env python3

import myLogger

class SubsysClass:
  def __init__(self, subsysName):
    self.name = subsysName
    self.currentTemp = 0

  def getTemp(self):
    return self.currentTemp

