#!/usr/bin/env python3

import threading
import time
import logging
import myLogger
import getFanSysConfig
import fanClass
import subsysClass
import random

theConfigFileName = 'fanSubsysConfig.txt'
keepGoing = True
newData = False
maxTestDriveCount = 10
logEm = myLogger.MyLogger()
    
class FanSubsystems(threading.Thread):

    def run(self):
        global newData
        global keepGoing
        global logEm

        while (keepGoing):
            if newData:
                dataTemperatureXfer = []
                for i in range(0,len(getFanSysConfig.subsysTopList)):
                    dataTemperatureXfer.append(getFanSysConfig.subsysTopList[i].currentTemp)
                maxTemp = max(dataTemperatureXfer)
                logEm.info('New subsystem temperatures = {}'
                      .format(dataTemperatureXfer))
                logEm.info('MaxTemp = {}'
                           .format(maxTemp))
                if (maxTemp >= 75):
                    logEm.info('setRPM(100%)')
                    self.setRPM(100)
                elif (maxTemp <= 25):
                    logEm.info('setRPM(20%)')
                    self.setRPM(20)
                else:
                    scaledRPMpercent = 20 + ((maxTemp-25)/(75-25))*(100-20)
                    logEm.info('setRPM({}%)'
                               .format(scaledRPMpercent))
                    self.setRPM(scaledRPMpercent)
                newData = False
                time.sleep(1.0)

    def setRPM(self, speedPercent):
        for i in range(0,len(getFanSysConfig.fanTopList)):
            getFanSysConfig.fanTopList[i].setSpeed(speedPercent)
            if i==len(getFanSysConfig.fanTopList)-1:
                formatString = 'getFanSysConfig.fanTopList[{}].commandedSpeed={}\n'
            else:
                formatString = 'getFanSysConfig.fanTopList[{}].commandedSpeed={}'
            logEm.info(formatString.format(i,getFanSysConfig.fanTopList[i].commandedSpeed))

def main():
    
    global newData
    global keepGoing
    global logEm

    logEm.info('------------ NEW EXECUTION STARTED ------------')
    print('------------ NEW EXECUTION STARTED ------------')

    getFanSysConfig.getFanSysConfig(theConfigFileName)

    fanSubsystems = FanSubsystems(name = "fanSubsystems")
    logEm.info('Starting fanSubsystems thread')
    print('\nStarting fanSubsystems thread\n')
    logEm.info('Maximum test driver temperature input cycles: {}\n'.format(maxTestDriveCount))
    print('Maximum test driver temperature input cycles: {}\n'.format(maxTestDriveCount))
    fanSubsystems.start()                  # ...Start the thread, invoke the run method

    xCnt = 0
    while xCnt < maxTestDriveCount:
        if random.uniform(0.0,1.0) > 0.5:
            # Get an upper range value
            myMin = 15
            myMax = 80
        else:
            # Get a lower range value
            myMin = -25
            myMax = 30  
        for i in range(0,len(getFanSysConfig.subsysTopList)):
            getFanSysConfig.subsysTopList[i].currentTemp = random.randint(myMin,myMax)                
        newData = True
        xCnt += 1
        time.sleep(.7)
        
    keepGoing = False

    logEm.info('main() test driver routine completed')
    print('\nmain() test driver routine completed\n')

if __name__ == '__main__':main()
