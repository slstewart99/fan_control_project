#!/usr/bin/env python3

import myLogger

class FanClass:
  def __init__(self, fanName, maxSpeed):
    self.name = fanName
    self.maxSpeed = int(maxSpeed)
    self.currentSpeed = 0
    self.commandedSpeed = 0

  def getSpeed(self):
    return self.currentSpeed

  def setSpeed(self, cmdSpeedPercent):
    self.commandedSpeed = (cmdSpeedPercent/100) * self.maxSpeed
    self.currentSpeed = self.commandedSpeed


    
