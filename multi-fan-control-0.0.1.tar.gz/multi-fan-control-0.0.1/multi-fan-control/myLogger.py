#!/usr/bin/env python3

import logging

logNameMaster = 'mfsLogger'
logIt = logging.getLogger(logNameMaster) # define my logger
logIt.setLevel(logging.INFO)            # All msgs INFO and above
handler = logging.FileHandler('multiFanSubsys.log') # create file handler
handler.setLevel(logging.INFO)
formatter = logging.Formatter(      # create my custom logging format
   '%(asctime)s: %(module)s: %(funcName)s: %(levelname)s: %(message)s',
   '%Y-%m-%d %H:%M:%S')
handler.setFormatter(formatter)
logIt.addHandler(handler)          # add the file handler to my logger

class MyLogger:
    global logIt
    
    '''
    logIt = logging.getLogger(logNameMaster) # define my logger
    logIt.setLevel(logging.INFO)            # All msgs INFO and above
    handler = logging.FileHandler('multiFanSubsys.log') # create file handler
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter(      # create my custom logging format
        '%(asctime)s: %(module)s: %(funcName)s: %(levelname)s: %(message)s',
        '%Y-%m-%d %H:%M:%S')
    handler.setFormatter(formatter)
    logIt.addHandler(handler)          # add the file handler to my logger
    '''
    def __init__(self):
        pass
    '''
        self.logIt = logging.getLogger(logNameMaster) # define my logger
        self.logIt.setLevel(logging.INFO)            # All msgs INFO and above
        handler = logging.FileHandler('multiFanSubsys.log') # create file handler
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter(      # create my custom logging format
            '%(asctime)s: %(module)s: %(funcName)s: %(levelname)s: %(message)s',
            '%Y-%m-%d %H:%M:%S')
        handler.setFormatter(formatter)
        self.logIt.addHandler(handler)          # add the file handler to my logger
        '''

    def info(self, msg):
        global logIt
        logIt.info(msg)

    def error(self, msg):
        global logIt
        logIt.error(msg)    
        

    
