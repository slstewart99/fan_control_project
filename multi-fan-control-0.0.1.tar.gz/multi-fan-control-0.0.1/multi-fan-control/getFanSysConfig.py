#!/usr/bin/env python3

from os import path
import sys
import myLogger
import fanClass
import subsysClass

# For reference, Fan & Subsys configFile format
# fanName1,     fanName2,     ..... [fanName10]
# maxRpmSpeed1, maxRpmSpeed2, ..... [maxRpmSpeed10]
# subSysName1,  subSysName2,  ..... [subSysName5]

fanTopList = []
subsysTopList = []
logEm = myLogger.MyLogger()

def getFanSysConfig(configFileName):
    
    if path.exists(configFileName):
        file1 = open(configFileName, 'r')
    else:
        print("\nCannot open \"{}\" config file.\n".format(configFileName))
        logEm.error('Cannot open \"{}\" config file'.format(configFileName))
        sys.exit(1)

    file_string1 = file1.read()
    file1.close()
    file_lines=file_string1.splitlines()

    print('\nfanSubsysConfig.txt input file contents:')
    logEm.info('fanSubsysConfig.txt input file contents:')
    for line in file_lines:
        print(line)
        logEm.info(line)

    fanList = file_lines[0].split(',')
    i=0
    for item in fanList:
        fanList[i]=item.strip()
        i+=1
    #print(fanList)
    
    fanSpeedList = file_lines[1].strip().split(',')
    i=0
    for item in fanSpeedList:
        fanSpeedList[i]=item.strip()
        i+=1
    #print(fanSpeedList)

    subsysList = file_lines[2].strip().split(',')
    i=0
    for item in subsysList:
        subsysList[i]=item.strip()
        i+=1
    #print(subsysList)

    if len(fanList) != len(fanSpeedList):
        print("\nERROR: len(fanList) != len(fanSpeedList)\n".format(configFileName))
        logEm.error('len(Fan Names) != len(Fan Speeds)')
        sys.exit(1)
    elif len(fanList)>10 or len(subsysList)>5:
        print("\nlen(fanList) is > 10 or len(subsysList) is > 5\n")
        logEm.error('len(fanList) is > 10 or len(subsysList) is > 5')
        sys.exit(1)

    for i in range(0,len(fanList)):
        fanInstance = fanClass.FanClass(fanList[i],fanSpeedList[i])
        fanTopList.append(fanInstance)

    for i in range(0,len(subsysList)):
        subsysInstance = subsysClass.SubsysClass(subsysList[i])
        subsysTopList.append(subsysInstance)

    logEm.info('Config file successfully input.')
    print('\nConfig file successfully input.')
